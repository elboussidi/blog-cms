-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 16 fév. 2019 à 13:31
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `blog`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id` int(58) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(89) NOT NULL,
  `password` varchar(60) NOT NULL,
  `lev` int(58) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `lev`) VALUES
(1, 'Ø¹Ø¨Ø¯ Ø§Ù„Ù…Ø¬ÙŠØ¯ Ø§Ù„Ø¨ÙˆØ³Ø¹ÙŠØ¯ÙŠ', 'abdelmajidboussidi@gmail.com', 'chichaoua132', 1),
(2, 'abdelmajid ', 'abdelmajid@gmq$ail.COM', '12345', 0),
(3, 'name', 'abdelmajid@gmail.com', '12345', 1);

-- --------------------------------------------------------

--
-- Structure de la table `com`
--

CREATE TABLE `com` (
  `id` int(58) NOT NULL,
  `autcom` varchar(80) NOT NULL,
  `com` text NOT NULL,
  `rank` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `com`
--

INSERT INTO `com` (`id`, `autcom`, `com`, `rank`) VALUES
(1, 'FGFGFGDF', '\r\n gygyutouy', 1),
(2, 'majid', 'test commonent\r\n ', 1),
(3, '', '\r\n Ø§ÙˆÙ„ ØªØ¹Ù„ÙŠÙ‚ Ù…Ù† Ù…Ø¬Ù‡ÙˆÙ„', 5),
(4, 'majid', '\r\n ØªØ¹Ù„ÙŠÙ‚ ØªØ¬Ø±ÙŠØ¨ÙŠ', 5);

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(58) NOT NULL,
  `title` varchar(80) NOT NULL,
  `img` varchar(89) NOT NULL,
  `post` text NOT NULL,
  `autor` varchar(66) NOT NULL,
  `dat add` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id`, `title`, `img`, `post`, `autor`, `dat add`) VALUES
(5, 'Ø¹Ù†ÙˆØ§Ù† Ø§Ù„Ù…Ù‚Ø§Ù„ ', ' http://localhost/blog/img/20180620_115710.png', ' Ù…Ù‚Ø§Ù„ ØªØ¬Ø±ÙŠØ¨ÙŠ', 'Ø¹Ø¨Ø¯ Ø§Ù„Ù…Ø¬ÙŠØ¯ Ø§Ù„Ø¨ÙˆØ³Ø¹ÙŠØ¯ÙŠ', '2019-02-16 12:29:30');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `com`
--
ALTER TABLE `com`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(58) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `com`
--
ALTER TABLE `com`
  MODIFY `id` int(58) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(58) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
